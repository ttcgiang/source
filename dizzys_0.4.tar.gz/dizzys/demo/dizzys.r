# all dizzys demos
demo(dizzysgene)
demo(plot.simul.cont)
demo(sirmodel)
demo(seir.stoch)


